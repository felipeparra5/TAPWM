﻿namespace PClasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblDataEmpresa = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.rbSIM = new System.Windows.Forms.RadioButton();
            this.rbNAO = new System.Windows.Forms.RadioButton();
            this.grpTrabalhaHome = new System.Windows.Forms.GroupBox();
            this.btnInstanciarMensalista = new System.Windows.Forms.Button();
            this.btnInstanciarParametro = new System.Windows.Forms.Button();
            this.grpTrabalhaHome.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(112, 96);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(73, 20);
            this.lblMatricula.TabIndex = 0;
            this.lblMatricula.Text = "Matrícula";
            this.lblMatricula.Click += new System.EventHandler(this.Label1_Click);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(112, 146);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(51, 20);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome";
            this.lblNome.Click += new System.EventHandler(this.Label2_Click);
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(112, 201);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(113, 20);
            this.lblSalario.TabIndex = 2;
            this.lblSalario.Text = "Salário Mensal";
            // 
            // lblDataEmpresa
            // 
            this.lblDataEmpresa.AutoSize = true;
            this.lblDataEmpresa.Location = new System.Drawing.Point(112, 258);
            this.lblDataEmpresa.Name = "lblDataEmpresa";
            this.lblDataEmpresa.Size = new System.Drawing.Size(217, 20);
            this.lblDataEmpresa.TabIndex = 3;
            this.lblDataEmpresa.Text = "Data de Entrada na Empresa";
            this.lblDataEmpresa.Click += new System.EventHandler(this.Label4_Click);
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(407, 90);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(166, 26);
            this.txtMatricula.TabIndex = 4;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(407, 140);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(166, 26);
            this.txtNome.TabIndex = 5;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(407, 198);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(166, 26);
            this.txtSalario.TabIndex = 6;
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(407, 258);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(166, 26);
            this.txtData.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 20);
            this.label5.TabIndex = 8;
            this.label5.Click += new System.EventHandler(this.Label5_Click);
            // 
            // rbSIM
            // 
            this.rbSIM.AutoSize = true;
            this.rbSIM.Location = new System.Drawing.Point(15, 80);
            this.rbSIM.Name = "rbSIM";
            this.rbSIM.Size = new System.Drawing.Size(63, 24);
            this.rbSIM.TabIndex = 9;
            this.rbSIM.TabStop = true;
            this.rbSIM.Text = "SIM";
            this.rbSIM.UseVisualStyleBackColor = true;
            this.rbSIM.CheckedChanged += new System.EventHandler(this.RadioButton1_CheckedChanged);
            // 
            // rbNAO
            // 
            this.rbNAO.AutoSize = true;
            this.rbNAO.Location = new System.Drawing.Point(15, 110);
            this.rbNAO.Name = "rbNAO";
            this.rbNAO.Size = new System.Drawing.Size(68, 24);
            this.rbNAO.TabIndex = 10;
            this.rbNAO.TabStop = true;
            this.rbNAO.Text = "NÃO";
            this.rbNAO.UseVisualStyleBackColor = true;
            this.rbNAO.CheckedChanged += new System.EventHandler(this.RadioButton2_CheckedChanged);
            // 
            // grpTrabalhaHome
            // 
            this.grpTrabalhaHome.Controls.Add(this.rbNAO);
            this.grpTrabalhaHome.Controls.Add(this.rbSIM);
            this.grpTrabalhaHome.Controls.Add(this.label5);
            this.grpTrabalhaHome.Location = new System.Drawing.Point(670, 96);
            this.grpTrabalhaHome.Name = "grpTrabalhaHome";
            this.grpTrabalhaHome.Size = new System.Drawing.Size(236, 193);
            this.grpTrabalhaHome.TabIndex = 11;
            this.grpTrabalhaHome.TabStop = false;
            this.grpTrabalhaHome.Text = "Trabalha em Home Office?";
            // 
            // btnInstanciarMensalista
            // 
            this.btnInstanciarMensalista.Location = new System.Drawing.Point(116, 356);
            this.btnInstanciarMensalista.Name = "btnInstanciarMensalista";
            this.btnInstanciarMensalista.Size = new System.Drawing.Size(213, 177);
            this.btnInstanciarMensalista.TabIndex = 12;
            this.btnInstanciarMensalista.Text = "Instanciar Mensalista";
            this.btnInstanciarMensalista.UseVisualStyleBackColor = true;
            this.btnInstanciarMensalista.Click += new System.EventHandler(this.Button1_Click);
            // 
            // btnInstanciarParametro
            // 
            this.btnInstanciarParametro.Location = new System.Drawing.Point(407, 356);
            this.btnInstanciarParametro.Name = "btnInstanciarParametro";
            this.btnInstanciarParametro.Size = new System.Drawing.Size(213, 177);
            this.btnInstanciarParametro.TabIndex = 13;
            this.btnInstanciarParametro.Text = "Instanciar Mensalista por Parametro";
            this.btnInstanciarParametro.UseVisualStyleBackColor = true;
            this.btnInstanciarParametro.Click += new System.EventHandler(this.Button2_Click);
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1199, 653);
            this.Controls.Add(this.btnInstanciarParametro);
            this.Controls.Add(this.btnInstanciarMensalista);
            this.Controls.Add(this.grpTrabalhaHome);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblDataEmpresa);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.grpTrabalhaHome.ResumeLayout(false);
            this.grpTrabalhaHome.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblDataEmpresa;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton rbSIM;
        private System.Windows.Forms.RadioButton rbNAO;
        private System.Windows.Forms.GroupBox grpTrabalhaHome;
        private System.Windows.Forms.Button btnInstanciarMensalista;
        private System.Windows.Forms.Button btnInstanciarParametro;
    }
}